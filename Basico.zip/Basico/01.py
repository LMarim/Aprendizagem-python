nome = "Lucas"
uni1= 6.3
uni2 = 6.9
uni3 = 7.5

calculo = (uni1+uni2+uni3)/3

#print("A média do aluno",nome,"é de:",calculo)

print(f"Sr.{nome} a sua média final foi de:{calculo:.1f}")
