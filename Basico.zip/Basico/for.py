pessoas = ['Paloma','Isadora','Lucas','Junior','Leo']

total = len(pessoas)

for x in range(total):
    if pessoas[x].startswith('L'):
        print(pessoas[x])
        
# for in pessoas:
#if x.startswith('L'):
#print(x)