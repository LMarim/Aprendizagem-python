lista=[22,32,44,56,12,22,78,56,11,75]

lista.sort()



print(max(lista))

#append() - adicionar um valor a ultima posição
#len() - informa a quantidade de itens de um vetor
#pop() - retira um elemento do vetor pela posição
#remove() - retira um elemento do vetor
#max() - iforma o maior valor do vetor
#min() - informa o menor valor do vetor
#sum() - calcula o somatorio do vetor
#sort() - reverte a ordem dos valores
#reverse() - reverte va ordem do valor
#insert -  adiciona um valor conforme a posição passada por parametro 
#startswith - acho que é meio obvio esse

